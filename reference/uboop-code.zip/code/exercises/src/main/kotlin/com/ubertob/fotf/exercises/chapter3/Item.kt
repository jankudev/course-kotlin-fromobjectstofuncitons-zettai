package com.ubertob.fotf.exercises.chapter3

enum class Item { carrot, milk }