package com.ubertob.fotf.zettai.domain

data class User(val name: String)