fun main() {
    println("Hello Functional World!")
}

